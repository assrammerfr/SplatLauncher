# Desktop Hackintosh EFI — BUILD NOTES

**Built:** 2026-11-07 ~05:20 UTC (2026-11-06 ~23:20 CST)
**Target:** Seth's desktop Hackintosh — boots the ALREADY INSTALLED macOS Ventura on the
Lite-On SATA SSD (moved from the laptop). No macOS reinstall; this EFI only replaces the
bootloader. Nothing was deployed to any machine — build only, on the VM.

## Hardware

| Part | Detail |
|---|---|
| CPU | Intel Core i7-4790 (Haswell, 4C/8T, 3.6–4.0 GHz, HD 4600 iGPU) |
| Board | **Generic Chinese B8H V2.5** (LGA 1150, B85 chipset, mATX). NOT an MSI B85M — the MSI logo in the photo was misleading. Off-brand/generic board. |
| GPU (primary) | AMD RX 5700 XT (Navi, natively supported in Ventura, full Metal acceleration). No framebuffer injection, no `-wegnoegpu`. |
| GPU (secondary) | HD 4600 iGPU — left to BIOS default; no framebuffer injected for it. |
| Storage | macOS Ventura already installed on the Lite-On SATA SSD (from the laptop). |
| Network | Ethernet only. No WiFi kexts. |

## Board assumptions — UNCONFIRMED, read before debugging

The B8H V2.5 is a generic Chinese board; its audio codec and LAN chip are **not confirmed**
(no datasheet, no visible model marking in the photo).

- **Audio:** AppleALC is included with `alcid=1` as the starting layout-id. These boards
  most commonly ship ALC887 or ALC892. If audio does not work, try in order:
  `alcid=1, 2, 3, 5, 7, 11` (edit NVRAM boot-args in config.plist). If none work, the
  codec may be something else entirely — check the codec chip marking on the board
  (small square chip near the audio jacks, usually labelled ALCxxx) and look up its
  supported layout-ids.
- **LAN:** RealtekRTL8111.kext v3.0.4 (Mieze) is included — Realtek GbE is the most common
  LAN on these boards. If Ethernet does not work, the board may have an Intel chip
  (then IntelMausi.kext is needed instead) or another Realtek variant. Check the LAN
  chip marking near the RJ45 jack to confirm.

## OpenCore

- **Version:** 1.0.8 (REL-108), from `~/workspace/downloads/OC108-full.zip`.
- **config.plist:** 36,825 bytes, built from the 1.0.8 `Docs/Sample.plist`. Parses clean.
- **OpenCore.efi:** 626,688 bytes (verified). BOOTx64.efi: 24,576 bytes.
- **ocvalidate was NOT run** (macOS/Windows binary, cannot run on the Linux VM).

## SMBIOS — iMac15,1 (Haswell Retina iMac, matches i7-4790 + dGPU)

Generated NEW values for this machine — do NOT reuse the laptop's MacBookPro14,1 values.

- SystemProductName: `iMac15,1`
- SystemSerialNumber: `C02LP5N3WMO2`
- MLB: `C0253ND8Q5GNHXALP`
- SystemUUID: `3B5D1E52-F82A-4A43-8966-9D5457A573FC`
- ROM: `5e09dc394751`
- PlatformInfo → UpdateSMBIOSMode: `Custom`
- Kernel → Quirks → CustomSMBIOSGuid: `True` (dual-boot protection, same as the laptop build)

## Kexts (Kernel → Add, in order)

| # | Kext | Version | Source |
|---|---|---|---|
| 1 | Lilu.kext | 1.7.2 | reused from laptop EFI |
| 2 | VirtualSMC.kext | 1.3.8 | reused from laptop EFI |
| 3 | WhateverGreen.kext | 1.7.1 | reused from laptop EFI |
| 4 | AppleALC.kext | 1.9.8 | reused from laptop EFI |
| 5 | SMCProcessor.kext | 1.3.8 | reused from laptop EFI |
| 6 | SMCSuperIO.kext | 1.3.8 | reused from laptop EFI |
| 7 | RealtekRTL8111.kext | 3.0.4 | Mieze RTL8111_driver_for_OS_X v3.0.0 release (GitHub) |

Deliberately EXCLUDED (laptop-only, not needed on desktop): VoodooPS2Controller,
VoodooRMI, VoodooSMBus, itlwm, SMCBatteryManager (desktop SMBIOS has no battery).
No Ps2KeyboardDxe.efi driver (desktop uses USB keyboard).

## SSDTs (ACPI → Add, both Enabled)

- `SSDT-EC-USBX-DESKTOP.aml` — 7,341 bytes, DESKTOP variant (not the laptop one).
  Source: Dortania Getting-Started-With-ACPI, `extra-files/compiled/SSDT-EC-USBX-DESKTOP.aml`.
- `SSDT-PLUG.aml` — 693 bytes (upstream file `SSDT-PLUG-DRTNIA.aml`, saved as SSDT-PLUG.aml).
  Source: same repo, `extra-files/compiled/SSDT-PLUG-DRTNIA.aml`.
- Both verified: start with the `SSDT` signature, non-zero size, registered in config.

## UEFI Drivers (all Enabled)

OpenRuntime.efi, OpenHfsPlus.efi, ResetNvramEntry.efi (all from the OC108 release).
OpenShell.efi is also present in EFI/OC/Tools/ (optional).

## Config highlights

- Misc → Boot: ShowPicker True, Timeout 10, HideAuxiliary False.
- Misc → Security: SecureBootModel Default, Vault Optional. No `AllowNvramReset`
  (not a real OpenCore key — it caused a schema error on the laptop build).
- NVRAM boot-args: `-v keepsyms=1 debug=0x100 alcid=1`
  (remove `-v` later for a clean Apple-logo boot once it works).
- csr-active-config: `03000000`.
- Booter quirks: RebuildAppleMemoryMap True, SetupVirtualMap True.
- Kernel quirks: AppleCpuPmCfgLock True, AppleXcpmCfgLock True, XhciPortLimit False
  (mandatory for Ventura — True causes a boot loop).

## Verification (all pass)

- config.plist parses with plistlib.
- All 7 Kernel → Add BundlePaths exist on disk with Info.plist + binary.
- All 3 UEFI Drivers exist. OpenCore.efi is exactly 626,688 bytes.
- Both SSDTs exist in EFI/OC/ACPI/ and are registered in ACPI → Add.
- No Voodoo / itlwm / Ps2KeyboardDxe entries anywhere in the config.
- No laptop SMBIOS values reused (serial/MLB/UUID all new).

## Known context (why this EFI exists)

- The laptop's drives (Samsung NVMe = Windows, Lite-On SATA = macOS) were moved to this
  desktop after the laptop stopped detecting them in BIOS. The drives and their data are
  intact (detected fine on the desktop).
- The laptop EFI (MacBookPro14,1, HD 630 framebuffer, VoodooPS2) boot-loops macOS on this
  desktop — wrong SMBIOS/framebuffer/kexts for Haswell. This desktop EFI replaces it.
- **Windows boot is currently broken on the NVMe:** the laptop EFI deploy used
  `rsync --delete`, which likely deleted `EFI/Microsoft/` (Windows Boot Manager) from the
  NVMe ESP — selecting "Windows Boot Manager" in BIOS falls through to OpenCore instead
  of Windows. Fix: boot a Windows installer USB and run `bcdboot` to rebuild the Windows
  boot files. Windows data (C:) is untouched. Seth has no USB drive on hand as of
  2026-11-06 ~23:12 CST.

## Deploy (for the parent agent, when Seth is ready)

This EFI is a build only. To use it: copy `EFI/` onto the SATA SSD's ESP (or a USB
stick's EFI partition), boot the desktop, pick the drive in BIOS/F11, and select macOS
from the OpenCore picker. If it kernel-panics, the first suspects are the unconfirmed
audio codec (try other alcid values) and the LAN chip (see above).
