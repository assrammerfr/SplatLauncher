# Fresh OpenCore 1.0.8 EFI — MSI GP72MVR 7RFX (Ventura 13.7.8)

Built from scratch on the VM, 2026-11-06 ~21:20 CST. NOT deployed to the laptop — no ESP writes, no reboots. Drop the `EFI/` folder onto an ESP to test.

## OpenCore

- Version: **1.0.8** (REL-108, from `OC108-full.zip`)
- `EFI/OC/OpenCore.efi`: 626,688 bytes (verified)
- `EFI/BOOT/BOOTx64.efi`: 24,576 bytes (verified)
- `config.plist`: built from the 1.0.8 `Docs/Sample.plist`, parses clean with plistlib. **Not** validated with `ocvalidate` (macOS/Windows binary, cannot run on the Linux VM) — path and schema checks were done by hand instead.

## SMBIOS

- Model: **MacBookPro14,1**
- Serial: C02X1DZVHV29
- MLB: C02827270J9HWVP8C
- SystemUUID: 68A90904-E028-43AB-A147-EA168335E06D (reused from the old config)
- ROM: 02:ff:ba:c5:e0:be (reused from the old config)

## Key config settings

- Misc → Boot: ShowPicker True, Timeout 10, HideAuxiliary False (Reset NVRAM visible without Spacebar)
- Misc → Security: SecureBootModel Default, Vault Optional
- NVRAM boot-args: `-v keepsyms=1 debug=0x100 alcid=3 -wegnoegpu igfxonln=1`
- csr-active-config: 03000000
- Booter → Quirks: RebuildAppleMemoryMap True, SetupVirtualMap True
- Kernel → Quirks: AppleCpuPmCfgLock True, AppleXcpmCfgLock True, **CustomSMBIOSGuid True** (dual-boot protection)
- PlatformInfo → UpdateSMBIOSMode: **Custom** (dual-boot protection — keeps the SMBIOS out of Windows)
- ACPI: two SSDTs (added 2026-11-06 ~21:29 CST, see "SSDTs" below)
- UEFI → Drivers (all Enabled): OpenRuntime.efi, OpenHfsPlus.efi, Ps2KeyboardDxe.efi, ResetNvramEntry.efi
- Tools: OpenShell.efi (1,183,744 bytes, from the OC108 release — optional, per the guide)

## SSDTs (added 2026-11-06 ~21:29 CST)

Prebuilt AML files from Dortania's Getting-Started-With-ACPI repo (`dortania/Getting-Started-With-ACPI`, `extra-files/compiled/` on master), downloaded via raw.githubusercontent.com. NOT written from scratch. Both verified: start with the "SSDT" signature.

| File | Size | Source file in repo | Purpose |
|------|------|---------------------|---------|
| SSDT-EC-USBX-LAPTOP.aml | 335 B | `SSDT-EC-USBX-LAPTOP.aml` | Embedded controller + USB power fix for laptops |
| SSDT-PLUG.aml | 693 B | `SSDT-PLUG-DRTNIA.aml` (saved as `SSDT-PLUG.aml`) | CPU power management unlock for i7-7700HQ |

Both are registered in config.plist ACPI → Add, Enabled True, with Comments. Note the PLUG source file is named `SSDT-PLUG-DRTNIA.aml` upstream; the guide names it `SSDT-PLUG.aml`, so it was saved under that name.

## Kexts (Kernel → Add order, all x86_64)

Updated 2026-11-06 ~21:29 CST: **SMCBatteryManager moved to position 3, directly after VirtualSMC**, per the guide's Kernel → Add order.

| # | Kext | Version | Source |
|---|------|---------|--------|
| 1 | Lilu.kext | 1.7.2 | Laptop NVMe ESP (`/Volumes/NO NAME 1/EFI/OC/Kexts/` via macOS SSH) |
| 2 | VirtualSMC.kext | 1.3.8 | `VirtualSMC-1.3.8-RELEASE.zip` (VM downloads) |
| 3 | SMCBatteryManager.kext | 1.3.8 | `VirtualSMC-1.3.8-RELEASE.zip` (extracted to `vsmc138/Kexts/`) |
| 4 | WhateverGreen.kext | 1.7.1 | Laptop NVMe ESP (via macOS SSH) |
| 5 | AppleALC.kext | 1.9.8 | Laptop NVMe ESP (via macOS SSH) |
| 6 | SMCProcessor.kext | 1.3.8 | `VirtualSMC-1.3.8-RELEASE.zip` |
| 7 | SMCSuperIO.kext | 1.3.8 | `VirtualSMC-1.3.8-RELEASE.zip` |
| 8 | VoodooPS2Controller.kext | 2.3.7 | `VoodooPS2Controller-2.3.7-RELEASE.zip` (VM downloads) |
| 9 | …/PlugIns/VoodooInput.kext | 1.1.6 (bundled) | inside VoodooPS2Controller 2.3.7 |
| 10 | …/PlugIns/VoodooPS2Keyboard.kext | 2.3.7 | inside VoodooPS2Controller 2.3.7 |
| 11 | …/PlugIns/VoodooPS2Trackpad.kext | 2.3.7 | inside VoodooPS2Controller 2.3.7 |
| 12 | …/PlugIns/VoodooPS2Mouse.kext | 2.3.7 | **Disabled** — steals the trackpad as a generic mouse |
| 13 | VoodooRMI.kext | 1.4.3 | `VoodooRMI-1.4.3-RELEASE.zip` (VM downloads) |
| 14 | VoodooSMBus.kext | 3.0 | inside `VoodooRMI-1.4.3` extract |
| 15 | …/PlugIns/RMISMBus.kext | 1.0 | inside VoodooRMI 1.4.3 |
| 16 | itlwm.kext | 2.3.0 | `itlwm-2.3.0` (VM downloads) |

Drivers are all from the OC108 release (`X64/EFI/OC/Drivers/`), including Ps2KeyboardDxe.efi (same 1.0.8 driver as the ESP copy).

## Deliberately NOT included

- **AllowNvramReset** — NOT a real OpenCore key. It was in the old broken config and caused `OCS: No schema for AllowNvramReset`. Reset NVRAM comes from the ResetNvramEntry.efi driver, which is enabled.
- **VoodooRMI.kext/Contents/PlugIns/VoodooInput.kext** — NOT in Kernel → Add. That file does not exist in the ESP's VoodooRMI copy and listing it caused a black-screen hang. (Note: the VM's VoodooRMI 1.4.3 release bundle does contain a VoodooInput.kext file inside its PlugIns folder, but it is not referenced by the config, so OpenCore will not load it.)

## Known warnings / open items

- **Duplicate-kext trap (from the 21:12 kernel panic):** these same kexts also exist in the Mac's `/Library/Extensions` (Preboot cache: VoodooInput, VoodooPS2Keyboard/Trackpad, VoodooRMI, VoodooSMBus, SMCBatteryManager). Booting via OpenCore with this EFI while those remain in `/Library/Extensions` risks the same duplicate-bundle-ID prelink panic. Before testing this EFI, decide: OpenCore-only (remove the duplicates from `/Library/Extensions`) or Preboot-only (do not use this EFI). Do NOT run both at once.
- The socheatsok78 MSI-GP62MVR-7RF EFI (v0.0.1, Jan 2020) was checked and REJECTED: OpenCore 0.5.x era, MacPro5,1 SMBIOS, no VoodooPS2 kexts. Not used.
- `ocvalidate` was not run (no macOS/Windows host available on the VM). Run it on the laptop before trusting the config fully.
- Total size: ~24 MB (was ~23 MB; +1.1 MB OpenShell.efi, +~1 KB SSDTs).
